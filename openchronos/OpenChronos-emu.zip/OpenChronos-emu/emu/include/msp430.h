/* Fake file */

#include <stdint.h>

#define MRFI_CC1100

//typedef unsigned short uint16_t
